## helper functions
