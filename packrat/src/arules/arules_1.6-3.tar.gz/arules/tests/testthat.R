library("testthat")

library("arules")
test_check("arules")